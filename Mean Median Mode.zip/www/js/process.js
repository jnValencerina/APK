Framework7.prototype.plugins.math = function (app, params) {
    if (!params) return;

    var stat = function(){
        'use strict';
        return {
            mean: function(num){
                var y = 0;
                $.each(num,function(a,b){
                    y = y + b;
                })
                return Math.round(y/num.length);
            },
            median: function(numbers){
                var median = 0,
                numsLen = numbers.length;
                numbers.sort();
                if (numsLen % 2 === 0) { 
                    median = (numbers[numsLen / 2 - 1] + numbers[numsLen / 2]) / 2;
                } 
                else 
                { 
                    median = numbers[(numsLen - 1) / 2];
                }
                return median;
            },

            
                 mode: function(x) {
   var counter = 1,repeated = 1,arrMode=[],elemNumber = 0,i;
   for (i=1;i<x.length ; i++)
    {
        if (x[i]==x[i-1]){
           counter++;
           if (counter>repeated) {
              repeated = counter;
              elemNumber = 0;
              arrMode = [];
              arrMode[elemNumber] = x[i]
           }
           else{
              if(counter==repeated && counter>1)   {
                 elemNumber++;
                 arrMode[elemNumber] = x[i];
              }
           }
        }
        else{
           counter = 1;
        }
    }
    if (arrMode.length >0){
    
    return arrMode;
    }
    return "None."

           }
        }
     
    }();

    return {
        hooks: {
            appInit: function () {
   
  $$("#btn_calc").click(function() {
        var input = $$("#input_ages").val().split(',');
      
        $$.each(input,function(a,b){
            input[a]=parseInt(input[a]);
        });

    $$("#statSolutions").html("Mean:"+stat.mean(input)+"<br>Median:"+stat.median(input)+"<br>Mode:"+stat.mode(input));
   
   
});
    }
    }
};
};

var $$ = Dom7;
var app = new Framework7({
    material:true,
    math:true
});




